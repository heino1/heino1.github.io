---
title: "Projekt 1"
date: 2025-04-27
draft: false
---

# Projekt 1

See on esimene näidisprojekt. Siin on projekti kirjeldus ja detailid.

## Projekti eesmärgid

- Luua innovaatiline lahendus
- Parandada kasutajakogemust
- Optimeerida ressursside kasutust

## Tehnoloogiad

- Hugo
- CSS
- JavaScript
